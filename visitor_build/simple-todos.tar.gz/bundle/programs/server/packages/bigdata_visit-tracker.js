(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var headers = Package['gadicohen:headers'].headers;

/* Package-scope variables */
var VisitTracker, parser, geoip;

(function(){

//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
// packages/bigdata_visit-tracker/packages/bigdata_visit-tracker.js             //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
                                                                                //
(function () {

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/bigdata:visit-tracker/visit-tracker.js                        //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
// Visit Tracker API - this will eventually be configurable               // 1
VisitTracker = {                                                          // 2
  options: {                                                              // 3
    collectionName: 'visits',                                             // 4
    defaultSource: 'ORG'                                                  // 5
  },                                                                      // 6
  visits: new Mongo.Collection('visits')                                  // 7
}                                                                         // 8
                                                                          // 9
// Insert the created datetime into the doc                               // 10
VisitTracker.visits.before.insert(function(userId, doc) {                 // 11
  return doc.createdAt = new Date();                                      // 12
});                                                                       // 13
////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/bigdata:visit-tracker/server.js                               //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
parser = Npm.require('ua-parser');                                        // 1
geoip = Npm.require('geoip-lite');                                        // 2
                                                                          // 3
Meteor.methods({                                                          // 4
                                                                          // 5
  /**                                                                     // 6
   * Log the initial visit                                                // 7
   * @param  {Obect} tracking - An object containing tracking variables   // 8
   * @return {Object}  The initial visit record                           // 9
   */                                                                     // 10
  logVisit: function (tracking) {                                         // 11
    var h, r, visit, ip, geo, id;                                         // 12
                                                                          // 13
    // Get the headers from the method request                            // 14
    h = headers.get(this);                                                // 15
                                                                          // 16
    // Parse the user agent from the headers                              // 17
    r = parser.parse(h['user-agent']);                                    // 18
                                                                          // 19
    // Autodetect spiders and only log visits for real users              // 20
    if (r.device != 'spider') {                                           // 21
                                                                          // 22
      // Get the IP address from the headers                              // 23
      ip = headers.methodClientIP(this);                                  // 24
                                                                          // 25
      // Geo IP look up for the IP Address                                // 26
      geo = geoip.lookup(ip);                                             // 27
                                                                          // 28
      // Build the visit record object                                    // 29
      visit = {                                                           // 30
        referer: h.referer,                                               // 31
        ipAddress: ip,                                                    // 32
        userAgent:  {                                                     // 33
          raw: r.string,                                                  // 34
          browser: r.userAgent,                                           // 35
          device: r.device,                                               // 36
          os: r.os                                                        // 37
        },                                                                // 38
        trafficSource: tracking,                                          // 39
        geo: geo                                                          // 40
      };                                                                  // 41
                                                                          // 42
      // Insert the visit record                                          // 43
      id = VisitTracker.visits.insert(visit);                             // 44
                                                                          // 45
      visit._id = id;                                                     // 46
                                                                          // 47
      return visit                                                        // 48
                                                                          // 49
    } else {                                                              // 50
      return 'Spider Detected'                                            // 51
    }                                                                     // 52
  },                                                                      // 53
                                                                          // 54
  /**                                                                     // 55
   * Logs Return Visits into the visit record                             // 56
   * @param  {String} id - The initial visit record id                    // 57
   * @return {Object}  The updated visit record                           // 58
   */                                                                     // 59
  logReturnVisit: function (id) {                                         // 60
    VisitTracker.visits.update(id, {$push: {returnVisits: new Date()} }); // 61
    return VisitTracker.visits.findOne(id);                               // 62
  }                                                                       // 63
                                                                          // 64
});                                                                       // 65
////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['bigdata:visit-tracker'] = {}, {
  VisitTracker: VisitTracker
});

})();

//# sourceMappingURL=bigdata_visit-tracker.js.map
